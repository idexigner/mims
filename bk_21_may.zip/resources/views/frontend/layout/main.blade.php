
@include('frontend.layout.header')


@include('frontend.component.script.advertisement-script')
 @include('frontend.component.script.frontend-common-script')
{{--@include('frontend.component.script.frontend-drug-script') --}}

@yield('main-section')



@include('frontend.layout.footer')









