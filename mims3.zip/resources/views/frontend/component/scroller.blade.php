<div class="text-scroller">
    <div class="simple-marquee-container">
      <div class="marquee-sibling">
        {{ getSiteSetting('scroller_title') }}
      </div>
      <marquee width="100%" direction="left" height="100%" style="color: #ffffff; padding-top: 10px;">
        {{ getSiteSetting('scroller_text') }}
      </marquee>
    </div>
  </div>