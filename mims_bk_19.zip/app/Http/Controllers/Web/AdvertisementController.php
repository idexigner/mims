<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Advertisement;
use App\Models\AdvertisementPosition;
use Illuminate\Http\Request;
use App\Traits\LogExceptions;
use Yajra\DataTables\DataTables;
use Carbon\Carbon;


class AdvertisementController extends Controller
{
    use LogExceptions;

    
    // public function index($address_category='')
    // {
       
    //     return view('frontend.address')->with(compact('address_category'));
    // }

    public function get_home_advertisement(Request $request){
        try{

            $data['home_product_slider'] = $this->get_advertisement_slider("Home Page Product Slider Advertisement", 10);
            $data['home_advert_container_top'] = $this->get_advertisement_slider("Home Page Container Top Advertisement", 1);
            // $data = "asd";
            return response()->json([
                'message' => 'Get Advertisement', 
                'data' => $data
            ], 200);

        } catch (\Exception $ex) {

            $this->logException($ex, \Route::currentRouteName(), __METHOD__);
            return response()->json([
                    'message' => 'Something went wrong!',
                    'error' => $ex,
                    'message' => $ex->getMessage()
                ], 400);
        }
    }

    public function get_advertisement_slider($position, $limit) 
    {
        $today = Carbon::today()->toDateString();
        return Advertisement::with('advertisement_position')
                ->whereHas('advertisement_position', function ($query) use ($position) {
                    $query->where('advertisement_position_name', $position);
                })
                ->where('advertisement_is_active',1)
                ->whereDate('advertisement_publish', '<=', $today)
                ->whereDate('advertisement_unpublish', '>=', $today)
                ->limit($limit ?? 1)
                ->orderBy('advertisement_id', 'desc')
                ->get();
    }

}
