<style>
    #home-product-slider {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .home-product-slide {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>

<script>
    function getAdvertisements(v){

        switch(v){
            case 'home':
                advertisementMethods.home();
            break;
            

            default:
        }
    }

    var advertisementMethods = {

        home: function(){
            $.ajax({
                url: "{{ route('get_home_advertisement')}}",
                type: 'GET',
                dataType: 'json',
                // data: {
                //     position: 'Home Page Product Slider Advertisement',
                //     limit: 10
                // },
                success: function(response) {
                    console.log("get_home_advertisement-> ", response);
                    advertisementMethods.slider(response.data.home_product_slider, "#home-product-slider")
                    advertisementMethods.single(response.data.home_advert_container_top[0], ".home-advert-container-top")
               

                },
                error: function(xhr, status, error) {
                    console.group("Error Block");
                    console.log(xhr);
                    console.log(status);
                    console.log(error);
                    console.groupEnd();
                }
            });
        },
        slider: function(data, target){

            $(target).html('');

            $.each(data, function(index, adv) {            
                var slide = '<div class="m-2 p-2"><a href="' + adv.advertisement_link + '" class="home-product-slide" style="background-image: url({{url('/')}}/storage/images/advertisement/'+adv.advertisement_image+'); min-height: '+adv.advertisement_position.advertisement_position_height+'px; color: transparent">..</a></div>';
                $(target).append(slide);                       
            });

            $(target).slick({
                slidesToScroll: 1,
                slidesToShow: 3,
                autoplay: true,
                autoplaySpeed: 3000,
                infinite: true,
                arrows: false,
                responsive: [{
                    breakpoint: 480,
                    settings: {
                    slidesToShow: 2,
                    }
                }]
            });

        },
        single: function(data, target){
            $(target).append('<a href="' + data.advertisement_link + '" class="advert no-outline" style="background-image: url({{url('/')}}/storage/images/advertisement/'+data.advertisement_image+'); min-height: '+data.advertisement_position.advertisement_position_height+'px; background-position: center; background-size: cover; color: transparent; display: flex;">..</a>');

            // $(target).append('<a href="' + data.advertisement_link + '" class="advert no-outline"><img src="{{url('/')}}/storage/images/advertisement/'+data.advertisement_image+'" alt="" style="min-height: '+data.advertisement_position.advertisement_position_height+'px; color: transparent"></a>');
        }
    }
</script>